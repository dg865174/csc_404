
const express = require('express');
const router = express.Router();

router.get('/', function(req, res, next){
    res.render('index', {title: "Users"})
})
var users = [
    {
        name: "David",
        gender: "Male"
    },
    {
        name: "Abigail",
        gender: "Female"
    }
];
console.log('in homeController pass 1');
router.showUsers = (req, res) => {
    res.render('users', {
        allUsers: users, title: "Users"
    });
};
console.log('in homeController pass 2');
router.addUsers = (req, res) => {
    console.log('in homeController addUsers');
    var newuserName = req.body.name;
    console.log("user " + newuserName);
    var newUserGender = req.body.gender;
    console.log("gender " + newUserGender)
    users.push({name: newuserName, gender: newUserGender});
    allUsers = users;
    res.render('users', {
        allUsers: users
    });
};
console.log('in homeController pass 3');
router.getNewUser = (req, res) => {
    console.log("in homeController getNewUser");
    res.render('newUsers', {title: "New User"});
};
module.exports = router;