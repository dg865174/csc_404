const User = require( '../models/User' );

exports.getAllUsers = ( req, res ) => {
  User.find( {} )
    .exec()
    .then( ( users ) => {
      res.render( 'users', {
        allUsers: users
      } );
    } )
    .catch( ( error ) => {
      console.log( error.message );
      return [];
    } )
    .then( () => {
      console.log( 'promise complete' );
    } );
};

exports.getUserPage = ( req, res ) => {
  res.render( 'newUsers' )
};

exports.saveUser = ( req, res ) => {
  let newUser = new User( {
    name: req.body.name,
    gender: req.body.gender
  } );

  newUser.save()
    .then( (result) => {
      res.render( 'thanks', {
        allUsers: result
      });
    } )
    .catch( error => {
      res.send( error );
    } );
};
